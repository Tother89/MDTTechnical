﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Generator_Console
{
    public class Datasets
    {
        private List<List<decimal>> datasets { get; set; }


        public Datasets(List<List<decimal>> datasets)
        {
            this.datasets = datasets;
        }        
    }
}
